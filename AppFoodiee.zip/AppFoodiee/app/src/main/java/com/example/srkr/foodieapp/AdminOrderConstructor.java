package com.example.srkr.foodieapp;

/**
 * Created by HP on 4/24/2018.
 */

public class AdminOrderConstructor {
    String id;
    String username;
    String foodname;
    String amount;
    String status;

    public AdminOrderConstructor(String id, String username, String foodname, String amount, String status) {
        this.id=id;
        this.username=username;
        this.foodname=foodname;
        this.amount=amount;
        this.status=status;
    }




    public void setId(String id) {
        this.id = id;
    }
    public String getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getFoodname() {
        return foodname;
    }

    public void setFoodname(String foodname) {
        this.foodname = foodname;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }


}
