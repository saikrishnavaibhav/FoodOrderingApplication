package com.example.srkr.foodieapp;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.afollestad.materialdialogs.MaterialDialog;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class AdminUpdateDelete extends AppCompatActivity implements View.OnClickListener {
    EditText iname, irating, iprice, icategory;
    ImageView img;
    Button pickimg, update;
    String upfood;
    Mydatabase mydatabase;
    private static final int SELECT_PHOTO = 1;
    private static final int CAPTURE_PHOTO = 2;
    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_update_delete);
        mydatabase = new Mydatabase(this);
        update = (Button) findViewById(R.id.update);
        iname = (EditText) findViewById(R.id.itemname);
        irating = (EditText) findViewById(R.id.itemrating);
        iprice = (EditText) findViewById(R.id.itemprice);
        icategory = (EditText) findViewById(R.id.itemcategory);
        img = (ImageView) findViewById(R.id.img);
        pickimg = (Button) findViewById(R.id.pick);

        pd=new ProgressDialog(this);
        pd.setTitle("Updating...");
        pd.setMessage("processing please wait...!!");
        pd.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        pd.setMax(8);

        Bundle details = getIntent().getExtras();
        upfood = details.getString("fn");
        iname.setText(details.getString("fn"));
        irating.setText(details.getString("rt"));
        iprice.setText(details.getString("pr"));
        icategory.setText(details.getString("fc"));
        byte[] byteimg = details.getByteArray("fi");
        Bitmap bitmap = BitmapFactory.decodeByteArray(byteimg, 0, byteimg.length);
        img.setImageBitmap(bitmap);

        pickimg.setOnClickListener(this);
        update.setOnClickListener(this);

        if (ContextCompat.checkSelfPermission(AdminUpdateDelete.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            img.setEnabled(false);
            ActivityCompat.requestPermissions(AdminUpdateDelete.this, new String[]{Manifest.permission.CAMERA,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE}, 0);


        } else {
            img.setEnabled(true);
        }

        mydatabase = new Mydatabase(this);

        //bootom navigation
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

    }




    @Override
    public void onClick(final View view) {
        switch (view.getId()) {
            case R.id.pick:
                new MaterialDialog.Builder(this)
                        .title("select image from")
                        .items(R.array.uploadimage)
                        .itemsIds(R.array.itemid)
                        .itemsCallback(new MaterialDialog.ListCallback() {

                            @Override
                            public void onSelection(MaterialDialog dialog, View itemView, int position, CharSequence text) {
                                switch (position) {
                                    case 0:
                                        Intent picpick = new Intent(Intent.ACTION_PICK);
                                        picpick.setType("image/*");
                                        startActivityForResult(picpick, SELECT_PHOTO);
                                        break;

                                    case 1:
                                        Intent takepic = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                                        startActivityForResult(takepic, CAPTURE_PHOTO);
                                        break;
                                    case 2:
                                        img.setImageResource(R.drawable.logoed);
                                        break;
                                }

                            }
                        }).show();
                break;
            case R.id.update:

                pd.show();
            Bitmap bitmap = ((BitmapDrawable)img.getDrawable()).getBitmap();
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
            byte[] byteArray = stream.toByteArray();

            String n=iname.getText().toString();
            String r=irating.getText().toString();
            String p=iprice.getText().toString();
            String c=icategory.getText().toString();
                if(n.length()==0){
                    pd.cancel();
                    iname.setError("enter item name");
                    iname.requestFocus();
                }
                else if(r.length()==0){
                    pd.cancel();
                    irating.setError("enter rating");
                    irating.requestFocus();
                }
                else if(p.length()==0){
                    pd.cancel();
                    iprice.setError("enter price");
                    iprice.requestFocus();
                }
                else if(c.length()==0){
                    pd.cancel();
                    icategory.setError("enter item category");
                    icategory.requestFocus();
                }
                else {
                    long up = mydatabase.itemdataupdate(upfood, n, r, p, c, byteArray);
                    if (up > 0) {
                        pd.dismiss();
                        Toast.makeText(this, "updated item successfully", Toast.LENGTH_SHORT).show();
                        Intent ud = new Intent(AdminUpdateDelete.this, Adminexplore.class);
                        startActivity(ud);
                    } else {
                        pd.dismiss();
                        Toast.makeText(this, "failed to update item", Toast.LENGTH_SHORT).show();
                    }
                    break;

                }
        }

    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == 0) {
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED &&
                    grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                img.setEnabled(true);

            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == SELECT_PHOTO) {
            if (resultCode == RESULT_OK) {
                Uri imageUri = data.getData();
                try {

                    final InputStream imageStream = getContentResolver().openInputStream(imageUri);
                    final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
                    img.setImageBitmap(selectedImage);


                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }

            }

        } else if (requestCode == CAPTURE_PHOTO) {
            if (resultCode == RESULT_OK) {
                onCaptureImageResult(data);

            }
        }
    }


    private void onCaptureImageResult(Intent data) {

        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");

        img.setMaxWidth(200);
        img.setImageBitmap(thumbnail);
    }

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.add:
                    Intent h = new Intent(AdminUpdateDelete.this, Adminadd.class);
                    startActivity(h);
                    return true;
                case R.id.explore:
                    Intent e = new Intent(AdminUpdateDelete.this, Adminexplore.class);
                    startActivity(e);
                    return true;
                case R.id.app:
                    Intent a = new Intent(AdminUpdateDelete.this, MainHome.class);
                    startActivity(a);
                    return true;
            }
            return false;
        }
    };


}







    /*




    public void update(View view) {
        String u=up.getText().toString();
        LayoutInflater inflater = getLayoutInflater();
        View alertLayout = inflater.inflate(R.layout.alertupdate, null);
        iname=(EditText)alertLayout.findViewById(R.id.itemname);
        irating=(EditText)alertLayout.findViewById(R.id.itemrating);
        iprice=(EditText)alertLayout.findViewById(R.id.itemprice);
        icategory=(EditText) alertLayout.findViewById(R.id.itemcategory);
        img = (ImageView)alertLayout. findViewById(R.id.img);
        pickimg=(Button)alertLayout.findViewById(R.id.pick);
        pickimg.setOnClickListener(this);

        if (ContextCompat.checkSelfPermission(AdminUpdateDelete.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            img.setEnabled(false);
            ActivityCompat.requestPermissions(AdminUpdateDelete.this, new String[] { Manifest.permission.CAMERA,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE }, 0);


        } else {
            img.setEnabled(true);
        }



        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle("Update item");
        // this is set the view from XML inside AlertDialog
        alert.setView(alertLayout);
        // disallow cancel of AlertDialog on click of back button and outside touch
        alert.setCancelable(false);
        alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getBaseContext(), "Update Canceled", Toast.LENGTH_SHORT).show();
            }
        });

        alert.setPositiveButton("update", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

                Bitmap bitmap = ((BitmapDrawable)img.getDrawable()).getBitmap();
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
                byte[] byteArray = stream.toByteArray();

                String n=iname.getText().toString();
                String r=irating.getText().toString();
                String p=iprice.getText().toString();
                String c=icategory.getText().toString();
                String upname=up.getText().toString();
                mydatabase.itemdataupdate(upname,n,r,p,c,byteArray);
                iname.setText("");
                irating.setText("");
                iprice.setText("");
                icategory.setText("");
                img.setImageResource(R.drawable.food);



            }
        });
        AlertDialog dialog = alert.create();
        dialog.show();
    }

    @Override
    public void onClick(final View view) {
        switch (view.getId()){
            case R.id.pick:
                new MaterialDialog.Builder(this)
                        .title("select image from")
                        .items(R.array.uploadimage)
                        .itemsIds(R.array.itemid)
                        .itemsCallback(new MaterialDialog.ListCallback() {

                            @Override
                            public void onSelection(MaterialDialog dialog, View itemView, int position, CharSequence text) {
                                switch (position){
                                    case 0:
                                        Intent picpick=new Intent(Intent.ACTION_PICK);
                                        picpick.setType("image/*");
                                        startActivityForResult(picpick,SELECT_PHOTO);
                                        break;

                                    case 1:
                                        Intent takepic=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                                        startActivityForResult(takepic,CAPTURE_PHOTO);
                                        break;
                                    case 2:
                                        img.setImageResource(R.drawable.logoed);
                                        break;
                                }

                            }
                        }).show();
                break;
        }

    }



    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode==0){
            if (grantResults.length>0 &&
                    grantResults[0]==PackageManager.PERMISSION_GRANTED &&
                    grantResults[1]==PackageManager.PERMISSION_GRANTED){
                img.setEnabled(true);

            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode==SELECT_PHOTO){
            if (resultCode==RESULT_OK){
                Uri imageUri = data.getData();
                try {

                    final InputStream imageStream = getContentResolver().openInputStream(imageUri);
                    final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
                    img.setImageBitmap(selectedImage);


                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }

            }

        }else if(requestCode==CAPTURE_PHOTO){
            if (resultCode==RESULT_OK){
                onCaptureImageResult(data);

            }
        }
    }


    private void onCaptureImageResult(Intent data) {

       Bitmap thumbnail=(Bitmap)data.getExtras().get("data");

        img.setMaxWidth(200);
        img.setImageBitmap(thumbnail);
    }







    public void delete(View view) {
        String d=de.getText().toString();
    }
}


*/

