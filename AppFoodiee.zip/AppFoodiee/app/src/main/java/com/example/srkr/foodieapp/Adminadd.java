package com.example.srkr.foodieapp;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.afollestad.materialdialogs.MaterialDialog;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class Adminadd extends AppCompatActivity implements View.OnClickListener {

    Mydatabase mydatabase;
    ImageView img;
    Bitmap thumbnail;
    Button pickimg;
    EditText iname,irating,iprice,icategory;

    private static final int SELECT_PHOTO = 1;
    private static final int CAPTURE_PHOTO = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adminadd);
        iname=(EditText)findViewById(R.id.itemname);
        irating=(EditText)findViewById(R.id.itemrating);
        iprice=(EditText)findViewById(R.id.itemprice);
        icategory=(EditText)findViewById(R.id.itemcategory);
        img = (ImageView) findViewById(R.id.img);
        pickimg=(Button)findViewById(R.id.pick);


        pickimg.setOnClickListener(this);

        if (ContextCompat.checkSelfPermission(Adminadd.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            img.setEnabled(false);
            ActivityCompat.requestPermissions(Adminadd.this, new String[] { Manifest.permission.CAMERA,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE }, 0);


        } else {
            img.setEnabled(true);
        }

        mydatabase = new Mydatabase(this);

        //bootom navigation
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

    }


    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.add:
                    Intent h = new Intent(Adminadd.this, Adminadd.class);
                    startActivity(h);
                    return true;
                case R.id.explore:
                    Intent e = new Intent(Adminadd.this, Adminexplore.class);
                    startActivity(e);
                    return true;
                case R.id.app:
                    Intent a = new Intent(Adminadd.this, MainHome.class);
                    startActivity(a);
                    return true;
            }
            return false;
        }
    };

    @Override
    public void onClick(final View view) {
        switch (view.getId()){
            case R.id.pick:
                new MaterialDialog.Builder(this)
                        .title("select image from")
                        .items(R.array.uploadimage)
                        .itemsIds(R.array.itemid)
                        .itemsCallback(new MaterialDialog.ListCallback() {

                        @Override
                        public void onSelection(MaterialDialog dialog, View itemView, int position, CharSequence text) {
                            switch (position){
                                case 0:
                                    Intent picpick=new Intent(Intent.ACTION_PICK);
                                    picpick.setType("image/*");
                                    startActivityForResult(picpick,SELECT_PHOTO);
                                    break;

                                case 1:
                                    Intent takepic=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                                    startActivityForResult(takepic,CAPTURE_PHOTO);
                                    break;
                                case 2:
                                    img.setImageResource(R.drawable.logoed);
                                    break;
                            }

                        }
                    }).show();
                break;
        }

    }



    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode==0){
            if (grantResults.length>0 &&
                    grantResults[0]==PackageManager.PERMISSION_GRANTED &&
                    grantResults[1]==PackageManager.PERMISSION_GRANTED){
                img.setEnabled(true);

            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode==SELECT_PHOTO){
            if (resultCode==RESULT_OK){
                Uri imageUri = data.getData();
                try {

                    final InputStream imageStream = getContentResolver().openInputStream(imageUri);
                    final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
                    img.setImageBitmap(selectedImage);


                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }

            }

        }else if(requestCode==CAPTURE_PHOTO){
            if (resultCode==RESULT_OK){
                onCaptureImageResult(data);

            }
        }
    }


    private void onCaptureImageResult(Intent data) {

        thumbnail=(Bitmap)data.getExtras().get("data");

        img.setMaxWidth(200);
        img.setImageBitmap(thumbnail);
    }


    public void addtodb(View view) {
        Bitmap bitmap = ((BitmapDrawable)img.getDrawable()).getBitmap();
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byte[] byteArray = stream.toByteArray();

        String n=iname.getText().toString();
        String r=irating.getText().toString();
        String p=iprice.getText().toString();
        String c=icategory.getText().toString();

        if(n.length()==0){
            iname.setError("enter item name");
            iname.requestFocus();
        }
        else if(r.length()==0){
            irating.setError("enter rating");
            irating.requestFocus();
        }
        else if(p.length()==0){
            iprice.setError("enter price");
            iprice.requestFocus();
        }
        else if(c.length()==0){
            icategory.setError("enter item category");
            icategory.requestFocus();
        }
        else{
            mydatabase.itemdataenter(n,r,p,c,byteArray);
            iname.setText("");
            irating.setText("");
            iprice.setText("");
            icategory.setText("");
            img.setImageResource(R.drawable.food);

        }


  /*      if (s>0){
            Toast.makeText(this, "item added successfully", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(this, "item not added into database", Toast.LENGTH_SHORT).show();
        }

        */
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}

