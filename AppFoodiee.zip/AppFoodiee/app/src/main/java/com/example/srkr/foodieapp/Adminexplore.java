package com.example.srkr.foodieapp;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.ArrayList;

public class Adminexplore extends AppCompatActivity {

RecyclerView recyclerView;
    ArrayList<String> food;
    Mydatabase mydatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adminexplore);

        food = new ArrayList<>();
        mydatabase = new Mydatabase(this);
        food = mydatabase.itemdataretrieve();

        recyclerView = (RecyclerView) findViewById(R.id.recycleexplore);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new Adminexploreadapter(this, food));

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);


        SharedPreferences sharedPref=getSharedPreferences("Login", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPref.edit();

         try{
             Bundle b = getIntent().getExtras();

            editor.putString("username", b.getString("u"));
            editor.putString("password", b.getString("p"));
            editor.apply();
         }
         catch (Exception e){

         }

//update and delete items inserted by admin

    }


    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.add:
                    Intent h = new Intent(Adminexplore.this, Adminadd.class);
                    startActivity(h);
                    return true;
                case R.id.explore:
                    Intent e = new Intent(Adminexplore.this, Adminexplore.class);
                    startActivity(e);
                    return true;
                case R.id.app:
                    Intent a = new Intent(Adminexplore.this, MainHome.class);
                    startActivity(a);
                    return true;
            }
            return false;
        }
    };

    @Override
    public void onBackPressed() {

    }
}
