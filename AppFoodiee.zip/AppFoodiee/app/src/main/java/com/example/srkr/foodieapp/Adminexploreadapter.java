package com.example.srkr.foodieapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.provider.MediaStore;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.afollestad.materialdialogs.MaterialDialog;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

/**
 * Created by HP on 3/30/2018.
 */

public class Adminexploreadapter extends RecyclerView.Adapter<Adminexploreadapter.Viewholder>  {

    ArrayList food;
    Context ct;
    Mydatabase mydatabase;
    ProgressDialog pd;

    public Adminexploreadapter(Adminexplore adminexplore, ArrayList<String> food) {
        this.ct=adminexplore;
        this.food=food;
    }

    @Override
    public Adminexploreadapter.Viewholder onCreateViewHolder(ViewGroup parent, int viewType) {
        mydatabase=new Mydatabase(ct);
        pd=new ProgressDialog(ct);
        pd.setTitle("Deleting Item...");
        pd.setMessage("processing please wait...!!");
        pd.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        pd.setMax(8);
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.adminexplore,parent,false);
        return new Adminexploreadapter.Viewholder(v);

    }

    @Override
    public void onBindViewHolder(Adminexploreadapter.Viewholder holder, int position) {

        final FoodExplore fooditem= (FoodExplore) food.get(position);

        holder.fn.setText(fooditem.getName());
        holder.rt.setText(fooditem.getRating());
        holder.pr.setText(fooditem.getPrice());
        holder.fc.setText(fooditem.getCategory());
        final byte[] foodImage = fooditem.getImage();
        Bitmap bitmap = BitmapFactory.decodeByteArray(foodImage, 0, foodImage.length);
        holder.fi.setImageBitmap(bitmap);


        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                new MaterialDialog.Builder(ct)
                        .title("Modify the item")
                        .items(R.array.modifications)
                        .itemsIds(R.array.modiid)
                        .itemsCallback(new MaterialDialog.ListCallback() {

                            @Override
                            public void onSelection(MaterialDialog dialog, View itemView, int position, CharSequence text) {
                                switch (position){
                                    case 0:
                                        Intent adupdate=new Intent(ct,AdminUpdateDelete.class);
                                        adupdate.putExtra("fn",fooditem.getName());
                                        adupdate.putExtra("rt",fooditem.getRating());
                                        adupdate.putExtra("pr",fooditem.getPrice());
                                        adupdate.putExtra("fc",fooditem.getCategory());
                                        adupdate.putExtra("fi",foodImage);
                                        ct.startActivity(adupdate);

                                        break;

                                    case 1:
                                        pd.show();
                                       long del=mydatabase.deleteitem(fooditem.getName());
                                       if (del>0){
                                           pd.dismiss();
                                           Toast.makeText(ct, "item deleted", Toast.LENGTH_SHORT).show();
                                           ct.startActivity(new Intent(ct,Adminexplore.class));
                                       }
                                       else{
                                           pd.dismiss();
                                           Toast.makeText(ct, "unable to delete item", Toast.LENGTH_SHORT).show();

                                       }


                                        break;

                                }

                            }
                        }).show();

            }
        });

    }

    @Override
    public int getItemCount() {
        return food.size();
    }

    public class Viewholder extends RecyclerView.ViewHolder {

        TextView fn,rt,pr,fc;
        ImageView fi;
        LinearLayout linearLayout;
        public Viewholder(View itemView) {
            super(itemView);

            fn=(TextView)itemView.findViewById(R.id.foodname);
            rt=(TextView)itemView.findViewById(R.id.rating);
            pr=(TextView)itemView.findViewById(R.id.price);
            fc=(TextView)itemView.findViewById(R.id.category);
            fi=(ImageView)itemView.findViewById(R.id.foodimage);
            linearLayout=(LinearLayout)itemView.findViewById(R.id.linearLayout);
        }
    }
}
