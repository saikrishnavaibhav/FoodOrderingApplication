package com.example.srkr.foodieapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import java.util.ArrayList;
import java.util.Timer;

public class Cart extends AppCompatActivity {
    RecyclerView recyclerView;
    Mydatabase mydatabase;
    ArrayList food;
    Cartadapter cartadapter;
    Cartconstructor cartconstructor;
    TextView total,pay;
    int count=0;
    ArrayList fn;
    String userna;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        total = (TextView) findViewById(R.id.ItemTotal);
        pay = (TextView) findViewById(R.id.pay);
        fn=new ArrayList();

        mydatabase = new Mydatabase(this);


         sharedPreferences=getSharedPreferences("Login", Context.MODE_PRIVATE);
         userna=sharedPreferences.getString("username","");

        food = mydatabase.getcart(userna);
    //    final Cartconstructor fooditem= (Cartconstructor) food.get(position);

        final Cartadapter myadapter=new Cartadapter(this, food);

        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(myadapter);


        final ItemTouchHelper helper=new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP|ItemTouchHelper.DOWN,ItemTouchHelper.RIGHT|ItemTouchHelper.LEFT) {
            @Override
            public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {

                return false;
            }

            @Override
            public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
                 food.remove(viewHolder.getAdapterPosition());

                myadapter.notifyItemRemoved(viewHolder.getAdapterPosition());


            }
        });
        helper.attachToRecyclerView(recyclerView);

         //bootom navigation
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
       for(int i=0;i<food.size();i++) {
           cartconstructor = (Cartconstructor) food.get(i);
           int a = Integer.parseInt(cartconstructor.getT());
           count=count+a;
            }
       total.setText(String.valueOf(count));
           pay.setText(String.valueOf(count+40));





    }


    public void order(View view) {
     //   long pla=mydatabase.placeorder(food);


        for(int i=0;i<food.size();i++) {
            cartconstructor = (Cartconstructor) food.get(i);
            String a = cartconstructor.getFoodname();
           fn.add(a);

        }
        long x=mydatabase.placeorder(userna,fn,pay.getText().toString());
        if (x > 0) {
            mydatabase.ordersuccess(userna);
            startActivity(new Intent(Cart.this,Cart.class));
            Toast.makeText(this, "order successfully placed", Toast.LENGTH_SHORT).show();

        } else {
            Toast.makeText(this, "failed to place order", Toast.LENGTH_SHORT).show();
        }
    //    Toast.makeText(this, "order placed"+fn+total.getText().toString(), Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onBackPressed() {
        Intent h=new Intent(Cart.this,MainHome.class);
        startActivity(h);
    }


    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.home:
                    Intent h=new Intent(Cart.this,MainHome.class);
                    startActivity(h);
                    return true;
                case R.id.explore:
                    Intent e=new Intent(Cart.this,UserExplore.class);
                    startActivity(e);
                    return true;
                case R.id.account:
                    Intent a=new Intent(Cart.this,Profile.class);
                    startActivity(a);
                    return true;
            }
            return false;
        }
    };



}
