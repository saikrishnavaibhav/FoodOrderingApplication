package com.example.srkr.foodieapp;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.afollestad.materialdialogs.MaterialDialog;
import com.cepheuen.elegantnumberbutton.view.ElegantNumberButton;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

/**
 * Created by HP on 3/21/2018.
 */

public class Cartadapter extends RecyclerView.Adapter<Cartadapter.Viewolder>{

    ArrayList food;
    Context ct;
    Mydatabase mydatabase;
    SQLiteDatabase writable;
    int u;
    public Cartadapter(Cart cart, ArrayList food) {

        this.food=food;
        this.ct=cart;
    }

    @Override
    public Viewolder onCreateViewHolder(ViewGroup parent, int viewType) {
         mydatabase=new Mydatabase(ct);
        View v=LayoutInflater.from(parent.getContext()).inflate(R.layout.cartlist,parent,false);
        return new Cartadapter.Viewolder(v);
    }

    @Override
    public void onBindViewHolder(final Viewolder holder, int position) {
        final Cartconstructor fooditem= (Cartconstructor) food.get(position);


        holder.foodname.setText(fooditem.getFoodname());
        holder.rating.setText(fooditem.getRating());
        holder.price.setText(fooditem.getT());
        holder.del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String del=fooditem.getFoodname();
                new MaterialDialog.Builder(ct)
                        .title("Are you sure Delete item from cart?")
                        .items(R.array.delops)
                        .itemsIds(R.array.delids)
                        .itemsCallback(new MaterialDialog.ListCallback() {

                            @Override
                            public void onSelection(MaterialDialog dialog, View itemView, int position, CharSequence text) {
                                switch (position){
                                    case 0:
                                        long d=mydatabase.delcart(del);
                                            if(d>0){
                                                ct.startActivity(new Intent(ct,Cart.class));
                                            }
                                        break;
                                    case 1:
                                        ct.startActivity(new Intent(ct,Cart.class));
                                        break;

                                }

                            }
                        }).show();

            }
        });
        final byte[] foodImage = fooditem.getFoodimage();
        Bitmap bitmap = BitmapFactory.decodeByteArray(foodImage, 0, foodImage.length);
        holder.foodimage.setImageBitmap(bitmap);
        holder.elegantNumberButton.setNumber(fooditem.getQ());
        holder.elegantNumberButton.setOnValueChangeListener(new ElegantNumberButton.OnValueChangeListener() {
            @Override
            public void onValueChange(ElegantNumberButton view, int oldValue, int newValue) {
                int o=oldValue;
                int no=newValue;
                    int r= Integer.parseInt(fooditem.getPrice());
                    u=no*r;
                String s=fooditem.getFoodname();
                SharedPreferences user=ct.getSharedPreferences("Login", Context.MODE_PRIVATE);
                String userna=user.getString("username","");
                writable=mydatabase.getWritableDatabase();
                ContentValues values = new ContentValues();
                values.put("q",no);
                values.put("t", u);
                long up=writable.update("cart", values, "foodname=? AND usermail=?", new String[]{s,userna});
                if(up>0){
                    Toast.makeText(ct, ""+u, Toast.LENGTH_SHORT).show();
                    holder.price.setText(String.valueOf(u));
                    ct.startActivity(new Intent(ct,Cart.class));
                }
                else {
                    Toast.makeText(ct, "damn", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }

    @Override
    public int getItemCount() {
        return food.size();
    }

    public class Viewolder extends RecyclerView.ViewHolder {

        TextView price;
        TextView foodname;
        ImageView foodimage;
        TextView rating;
        Button del;
        ElegantNumberButton elegantNumberButton;
        public Viewolder(View itemView) {
            super(itemView);

            price=(TextView)itemView.findViewById(R.id.price);
            foodimage=(ImageView)itemView.findViewById(R.id.foodimage);
            foodname=(TextView)itemView.findViewById(R.id.foodname);
            rating=(TextView)itemView.findViewById(R.id.rating);
            del=(Button)itemView.findViewById(R.id.delete);
            elegantNumberButton=(ElegantNumberButton)itemView.findViewById(R.id.elegant);
        }
    }
}
