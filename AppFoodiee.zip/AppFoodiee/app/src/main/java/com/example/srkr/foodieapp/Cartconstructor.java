package com.example.srkr.foodieapp;

/**
 * Created by HP on 4/3/2018.
 */

public class Cartconstructor {
    String foodname;
    byte[] foodimage;
    String rating;
    int total;
    String q,t;
    String price;

    public Cartconstructor(String foodname, byte[] foodimage, String rating, String price, String q, String t) {
        this.foodname = foodname;
        this.foodimage = foodimage;
        this.rating = rating;
        this.price = price;
        this.q=q;
        this.t=t;


    }
    public String getT() {
        return t;
    }

    public void setT(String t) {
        this.t = t;
    }


    public String getQ() {
        return q;
    }

    public void setQ(String q) {
        this.q = q;
    }


    public String getFoodname() {
        return foodname;
    }

    public void setFoodname(String foodname) {
        this.foodname = foodname;
    }

    public byte[] getFoodimage() {
        return foodimage;
    }

    public void setFoodimage(byte[] foodimage) {
        this.foodimage = foodimage;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }



}
