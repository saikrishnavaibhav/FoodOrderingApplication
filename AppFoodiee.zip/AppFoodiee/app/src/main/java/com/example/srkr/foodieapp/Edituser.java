package com.example.srkr.foodieapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.utility.RegexTemplate;

import static com.basgeekball.awesomevalidation.ValidationStyle.BASIC;

public class Edituser extends AppCompatActivity {

    EditText un,mb,ad,m;
    Mydatabase mydatabase;
    ProgressDialog pd;
    String userna;
    AwesomeValidation awesomeValidation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edituser);

        un=(EditText)findViewById(R.id.username);
        mb=(EditText)findViewById(R.id.mobileno);
        m=(EditText)findViewById(R.id.mail);
        ad=(EditText)findViewById(R.id.adress);

        mydatabase=new Mydatabase(this);

        awesomeValidation = new AwesomeValidation(BASIC);

        awesomeValidation.addValidation(this, R.id.username, RegexTemplate.NOT_EMPTY,R.string.name);
        awesomeValidation.addValidation(this, R.id.mail, Patterns.EMAIL_ADDRESS, R.string.email);
        awesomeValidation.addValidation(this, R.id.mobileno, "^[0-9]{10}$", R.string.mobileno);
        awesomeValidation.addValidation(this, R.id.adress, RegexTemplate.NOT_EMPTY,R.string.address);


        SharedPreferences preferences =getSharedPreferences("Login", Context.MODE_PRIVATE);


        // Toast.makeText(this, ""+user, Toast.LENGTH_SHORT).show();
        userna=preferences.getString("username","");
        pd=new ProgressDialog(this);
        pd.setTitle("Updating...");
        pd.setMessage("processing please wait...!!");
        pd.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        pd.setMax(8);
        Bundle b=getIntent().getExtras();
        un.setText(b.getString("u"));
        mb.setText(b.getString("m"));
        m.setText(b.getString("e"));
        ad.setText(b.getString("a"));



    }

    public void submit(View view) {

        String u=un.getText().toString();
        String mm=mb.getText().toString();
        String e=m.getText().toString();
        String a=ad.getText().toString();
        if (awesomeValidation.validate()) {
            pd.show();
            pd.setCancelable(false);
            mydatabase.edit(u,e,mm,a,userna);

            finish();

        }


    }
}
