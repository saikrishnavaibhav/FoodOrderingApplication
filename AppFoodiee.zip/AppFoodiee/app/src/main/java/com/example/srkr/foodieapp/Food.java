package com.example.srkr.foodieapp;

public class Food {
    String foodname,foodimage,rating,price;

    public Food(String foodname, String foodimage, String rating, String price) {
        this.foodname = foodname;
        this.foodimage = foodimage;
        this.rating = rating;
        this.price = price;
    }

    public String getFoodname() {
        return foodname;
    }

    public void setFoodname(String foodname) {
        this.foodname = foodname;
    }

    public String getFoodimage() {
        return foodimage;
    }

    public void setFoodimage(String foodimage) {
        this.foodimage = foodimage;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }
}
