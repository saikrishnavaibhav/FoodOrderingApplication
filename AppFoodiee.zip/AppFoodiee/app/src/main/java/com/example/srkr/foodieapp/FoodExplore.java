package com.example.srkr.foodieapp;

/**
 * Created by HP on 3/30/2018.
 */

public class FoodExplore {

    private String name;
    private String rating;
    private String price;
    private String category;
    private byte[] image;



    public FoodExplore(String name, String rating, String price, String category, byte[] image) {
        this.name = name;
        this.rating = rating;
        this.price = price;
        this.category = category;
        this.image = image;
    }




    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }


}
