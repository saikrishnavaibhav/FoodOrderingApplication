package com.example.srkr.foodieapp;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

/**
 * Created by HP on 3/16/2018.
 */
public class Foodadapter {}/* extends RecyclerView.Adapter<Foodadapter.Viewholder> {

    Mydatabase mydatabase;
    ArrayList<String> foodname,foodimage,rating,price;
    Context ct;

    public Foodadapter(Veg veg, ArrayList<String> foodname, ArrayList<String> foodimage, ArrayList<String> rating, ArrayList<String> price) {
        this.foodname=foodname;
        this.foodimage=foodimage;
        this.rating=rating;
        this.price=price;
        this.ct=veg;
    }

    @Override
    public Foodadapter.Viewholder onCreateViewHolder(ViewGroup parent, int viewType) {

        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.fooditems,parent,false);
        return new Foodadapter.Viewholder(v);

    }


    @Override
    public void onBindViewHolder(Foodadapter.Viewholder holder, final int position) {


        final String fn,fi,r,p;
        fn=foodname.get(position).toString();
        r=rating.get(position).toString();
        p=price.get(position).toString();

        holder.fn.setText(foodname.get(position).toString());
        holder.rt.setText(rating.get(position).toString());
        holder.pr.setText(price.get(position).toString());
         final String img=foodimage.get(position).toString();
        try {
            InputStream inputstream=ct.getAssets().open(img);
            Drawable d=Drawable.createFromStream(inputstream,null);
            holder.fi.setImageDrawable(d);

        } catch (IOException e) {
            e.printStackTrace();
        }
        holder.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(ct, "not entering into cart", Toast.LENGTH_SHORT).show();

            }
        });
    }



    @Override
    public int getItemCount() {
        return foodname.size();
    }

    public class Viewholder extends RecyclerView.ViewHolder {
        TextView fn,rt,pr;
        ImageView fi;
        Button button;

        public Viewholder(View itemView) {
            super(itemView);
            fn=(TextView)itemView.findViewById(R.id.foodname);
            rt=(TextView)itemView.findViewById(R.id.rating);
            pr=(TextView)itemView.findViewById(R.id.price);
            fi=(ImageView)itemView.findViewById(R.id.foodimage);

            button=(Button)itemView.findViewById(R.id.addtocart);

        }
    }
}
*/
