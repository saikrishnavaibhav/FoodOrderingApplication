package com.example.srkr.foodieapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class Home extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout mdrawer;
    NavigationView navigationView;
    private ActionBarDrawerToggle mtoggle;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mdrawer=(DrawerLayout)findViewById(R.id.drawer);
        mtoggle=new ActionBarDrawerToggle(this,mdrawer,R.string.open,R.string.close);
        mdrawer.addDrawerListener(mtoggle);
        mtoggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    //    navigationView = (NavigationView) findViewById(R.id.navigationview);
     //   navigationView.setNavigationItemSelectedListener(this);

    }

/*
    public void VEG(View view) {

        Intent veg=new Intent(Home.this,Veg.class);
        startActivity(veg);
    }

    public void NON_VEG(View view) {


        Intent nonveg=new Intent(Home.this,Nonveg.class);
        startActivity(nonveg);
    }
    */

    public void restaurants(View view) {

        Intent restaurants=new Intent(Home.this,Restaurants.class);
        startActivity(restaurants);
    }

    public void click(View view) {
        Intent cart=new Intent(Home.this,Cart.class);
        startActivity(cart);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(mtoggle.onOptionsItemSelected(item))
        {
            int id=item.getItemId();
            switch (id) {
              //  case R.id.special_items:
              //      Intent Splitems = new Intent(Home.this, Veg.class);
              //      startActivity(Splitems);
                //    break;
            }
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id=item.getItemId();
        switch (id) {
 //           case R.id.special_items:
//
  //              Intent Splitems = new Intent(Home.this, Veg.class);
    //            startActivity(Splitems);
      //          break;
        }
        return true;
    }
}
