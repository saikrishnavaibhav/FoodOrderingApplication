package com.example.srkr.foodieapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

public class Login extends AppCompatActivity {

    EditText email;
EditText pswd;
    Button login;
    Mydatabase mydatabase;
    ProgressDialog pd;
    SharedPreferences sharedPreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        email=(EditText)findViewById(R.id.email);
        pswd = (EditText) findViewById(R.id.password);
        login = (Button) findViewById(R.id.login);
        pd=new ProgressDialog(this);
        pd.setTitle("Logging in...");
        pd.setMessage("processing please wait...!!");
        pd.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        pd.setMax(8);
        mydatabase = new Mydatabase(this);


    }



    public void login(View view) {
        pd.show();
        pd.setCancelable(false);

        String e = email.getText().toString();
        String p = pswd.getText().toString();

        if (e.length() == 0 || p.length() == 0) {
            pd.dismiss();
            if(e.length()==0) {
                email.setError("enter your registered email");
            }
            if (p.length()==0) {
                pswd.setError("enter your password");
            }
            Toast.makeText(this, "Please fill the details", Toast.LENGTH_SHORT).show();
        }
        else if(e.equals("admin") && p.equals("admin")){
            pd.dismiss();
            Intent admin=new Intent(Login.this,Adminexplore.class);
            admin.putExtra("u","admin");
            admin.putExtra("p","admin");
            startActivity(admin);
            finish();
        }
        else
         {
                    pd.show();
                     mydatabase.login(e,p);
                     finish();
                 }
    }

    @Override
    public void onBackPressed() {

        super.onBackPressed();
        Intent admin=new Intent(Login.this,MainActivity.class);
        startActivity(admin);
    }
}
