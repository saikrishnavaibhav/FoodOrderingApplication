package com.example.srkr.foodieapp;

import android.content.Context;

/**
 * Created by HP on 4/2/2018.
 */

public class LoginConstructor {

String user;



    Context ct;
    public LoginConstructor(Login login) {
        this.ct=login;
    }

    public void user(String e) {
        this.user=e;

    }
    public String getUser() {
        return user;
    }

}
