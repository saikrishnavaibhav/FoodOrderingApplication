package com.example.srkr.foodieapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Animation animation,animtop;

    Button b1,b2;
    ImageView iv;
    SharedPreferences sharedPref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        animation= AnimationUtils.loadAnimation(this,R.anim.animation);
        animtop= AnimationUtils.loadAnimation(this,R.anim.animtop);
        b1=(Button)findViewById(R.id.signup);
        b2=(Button)findViewById(R.id.login);
        iv=(ImageView)findViewById(R.id.iv);

         sharedPref=getSharedPreferences("Login", Context.MODE_PRIVATE);
       if( sharedPref.getString("username","").equals("")){

           iv.setAnimation(animtop);
           b1.setAnimation(animation);
           b2.setAnimation(animation);
 }
      else {

           iv.setAnimation(animtop);
           b1.setAnimation(animation);
           b2.setAnimation(animation);

           // Wait();

           new Thread(new Runnable() {
               @Override
               public void run() {
                   try
                   {
                       Thread.sleep(1000);
                       if( sharedPref.getString("username","").equals("admin")){
                       Intent lo=new Intent(MainActivity.this,Adminexplore.class);

                       startActivity(lo);}
                       else{
                           Intent lo=new Intent(MainActivity.this,MainHome.class);

                           startActivity(lo);
                       } }
                   catch (InterruptedException e)
                   {
                       e.printStackTrace();
                   }
               }
           }).start();
          }
 }

    public void signup(View view) {
       Intent signup=new Intent(MainActivity.this,Registration.class);
        startActivity(signup);}

    public void login(View view) {
        Intent login=new Intent(MainActivity.this,Login.class);
        startActivity(login);
        }

    @Override
    public void onBackPressed() {

    }
}
