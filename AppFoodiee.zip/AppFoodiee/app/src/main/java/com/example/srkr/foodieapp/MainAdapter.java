package com.example.srkr.foodieapp;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Created by HP on 4/19/2018.
 */


public class MainAdapter extends RecyclerView.Adapter<MainAdapter.Viewholder> {

        String[] mydata;
        int[] image;
        Context ct;
        public MainAdapter(MainHome mainActivity, String[] name,int[] images) {
            this.mydata=name;
            this.ct=mainActivity;
            this.image=images;

        }

        @Override
        public Viewholder onCreateViewHolder(ViewGroup parent, int viewType) {

            View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.item,parent,false);
            return new Viewholder(v);
        }

        @Override
        public void onBindViewHolder(Viewholder holder, final int position) {

            holder.t1.setText(mydata[position]);
            holder.i1.setImageResource(image[position]);
            holder.linearLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    switch (position)
                    {
                        case 0:
                            Intent i=new Intent(ct,Splitem.class);
                            ct.startActivity(i);
                            break;
                        case 1:
                            Intent i1=new Intent(ct,juices.class);
                            ct.startActivity(i1);
                            break;
                        case 2:
                            Intent i2=new Intent(ct,salads.class);
                            ct.startActivity(i2);
                            break;
                        case 3:
                            Intent i3=new Intent(ct,Icecreams.class);
                            ct.startActivity(i3);
                            break;
                        case 4:
                        Intent i4=new Intent(ct,Starters.class);
                        ct.startActivity(i4);

                    }
                }
            });
        }

        @Override
        public int getItemCount() {
            return mydata.length;
        }

        public class Viewholder extends RecyclerView.ViewHolder {

            TextView t1;
            ImageView i1;
            LinearLayout linearLayout;
            public Viewholder(View itemView) {
                super(itemView);
                t1=(TextView)itemView.findViewById(R.id.tv);
                i1=(ImageView)itemView.findViewById(R.id.iv);
                linearLayout=(LinearLayout)itemView.findViewById(R.id.linear);
            }
        }
    }

