package com.example.srkr.foodieapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class MainHome extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private static ViewPager mPager;
    private static int currentPage = 0;
    private static int NUM_PAGES = 0;
    private static final Integer[] IMAGES= {R.drawable.nonveg,R.drawable.cheeseroll,R.drawable.mughalaiybiryani,R.drawable.caramelnutmilkshake,R.drawable.nonveg,R.drawable.cheeseroll,R.drawable.mughalaiybiryani,R.drawable.caramelnutmilkshake,R.drawable.nonveg,R.drawable.cheeseroll,R.drawable.mughalaiybiryani,R.drawable.caramelnutmilkshake,R.drawable.nonveg,R.drawable.cheeseroll,R.drawable.mughalaiybiryani,R.drawable.caramelnutmilkshake,R.drawable.nonveg,R.drawable.cheeseroll,R.drawable.mughalaiybiryani,R.drawable.caramelnutmilkshake,R.drawable.nonveg,R.drawable.cheeseroll,R.drawable.mughalaiybiryani,R.drawable.caramelnutmilkshake};
    private ArrayList<Integer> ImagesArray = new ArrayList<Integer>();

    RecyclerView recyclerview;
    Mydatabase mydatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);



        //imagesliding code

        init();

        SharedPreferences sharedPref=getSharedPreferences("Login", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPref.edit();

        try {

            Bundle b = getIntent().getExtras();
            editor.putString("username", b.getString("u"));
            editor.putString("password", b.getString("p"));
            editor.apply();
        }
        catch (Exception e){
            SharedPreferences sharedPreferences=getSharedPreferences("Login", Context.MODE_PRIVATE);
            String userna=sharedPreferences.getString("username","");
         //   ArrayList u=mydatabase.getuserdetails(userna);
       //    String  uu=u.get(0).toString();
           // Toast.makeText(this, "welcome back "+userna, Toast.LENGTH_SHORT).show();

        }




        //bottom navigation

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);



        recyclerview=(RecyclerView)findViewById(R.id.recycle);

        String[] name=new String[]{"Biryani's","juice's","salad's","icecream's","starters"};
        int[] images=new int[]{R.drawable.mughalaiybiryani,R.drawable.caramelnutmilkshake,R.drawable.greensalad,R.drawable.dryfriuticecrema,R.drawable.vegdumplings};

        recyclerview.setLayoutManager(new GridLayoutManager(this,2));
        recyclerview.setAdapter(new MainAdapter(this,name,images));

    }

    @Override
    public void onBackPressed() {
    }


    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.special_items) {
            Intent salad = new Intent(MainHome.this, Splitem.class);
            startActivity(salad);
            // Handle the camera action
        } else if (id == R.id.salads) {
            Intent salad = new Intent(MainHome.this, salads.class);
            startActivity(salad);

        } else if (id == R.id.juices) {
            Intent juices = new Intent(MainHome.this, juices.class);
            startActivity(juices);

        } else if (id == R.id.starters) {
            Intent salad = new Intent(MainHome.this, Starters.class);
            startActivity(salad);

        } else if (id == R.id.icecreams) {
            Intent salad = new Intent(MainHome.this, Icecreams.class);
            startActivity(salad);
        }

            DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
            drawer.closeDrawer(GravityCompat.START);
            return true;
        }




    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.home:
                    Intent h=new Intent(MainHome.this,MainHome.class);
                    startActivity(h);
                    return true;
                case R.id.explore:
                    Intent e=new Intent(MainHome.this,UserExplore.class);
                    startActivity(e);
                    return true;

                case R.id.account:
                    SharedPreferences preferences =getSharedPreferences("Login", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.clear();
                    editor.commit();
                    finish();
                   /* Intent a=new Intent(MainHome.this,Profile.class);
                    startActivity(a);
                    return true;*/
            }
            return false;
        }
    };


    public void click(View view) {
        Intent cart=new Intent(MainHome.this,Cart.class);
        startActivity(cart);
    }


    //image slider init method

    private void init() {
        for(int i=0;i<IMAGES.length;i++)
            ImagesArray.add(IMAGES[i]);

        mPager = (ViewPager) findViewById(R.id.pager);


        mPager.setAdapter(new Slidingimage_adapter(MainHome.this,ImagesArray));

        final float density = getResources().getDisplayMetrics().density;

//Set circle indicator radius


        NUM_PAGES =IMAGES.length;

        // Auto start of viewpager
        final Handler handler = new Handler();
        final Runnable Update = new Runnable() {
            public void run() {
                if (currentPage == NUM_PAGES) {
                    currentPage = 0;
                }
                mPager.setCurrentItem(currentPage++, true);
            }
        };
        Timer swipeTimer = new Timer();
        swipeTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(Update);
            }
        }, 4000, 3000);

        // Pager listener over indicator
    }


}

