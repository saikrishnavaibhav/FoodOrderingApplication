package com.example.srkr.foodieapp;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by HP on 3/12/2018.
 */

public class Mydatabase extends SQLiteOpenHelper {

    SQLiteDatabase writable, readable;
    Context ct;


    public Mydatabase(Context context) {
        super(context, "foodie", null, 5);
        this.ct = context;


    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        String query = "CREATE TABLE userdata(name TEXT,email TEXT PRIMARY KEY,mobileno INTEGER,password TEXT,address TEXT);";
        String cart = "CREATE TABLE cart(foodname TEXT PRIMARY KEY,foodimage BLOB,rating TEXT,price TEXT,q TEXT,t TEXT,usermail TEXT);";
        String items = "CREATE TABLE fooditems(itemname TEXT PRIMARY KEY,itemrating TEXT,itemprice TEXT,itemcategory TEXT,itemimage BLOB);";
        String orders = "CREATE TABLE orders(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT,foodname TEXT,amount TEXT,status TEXT);";

        sqLiteDatabase.execSQL(query);
        sqLiteDatabase.execSQL(cart);
        sqLiteDatabase.execSQL(items);
        sqLiteDatabase.execSQL(orders);




    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        sqLiteDatabase.execSQL("Drop table if exists userdata");
        sqLiteDatabase.execSQL("Drop table if exists fooditems");
        sqLiteDatabase.execSQL("Drop table if exists cart");
        sqLiteDatabase.execSQL("Drop table if exists orders");

        onCreate(sqLiteDatabase);
    }

    public long insertdata(String n, String e, String m, String p, String a) {

        ContentValues values = new ContentValues();
        values.put("name", n);
        values.put("email", e);
        values.put("mobileno", m);
        values.put("password", p);
        values.put("address", a);
        writable = getWritableDatabase();
        return writable.insert("userdata", null, values);

    }


    public int login(String e, String p) {

        readable = getReadableDatabase();
        Cursor c = readable.rawQuery("select password from userdata where email='" + e + "';", null);

        while (c.moveToFirst()) {
            String password = c.getString(0);

            if (p.equals(password)) {

                Intent s=new Intent(ct, MainHome.class);
                s.putExtra("u",e);
                s.putExtra("p",password);
                ct.startActivity(s);

            } else {
                Toast.makeText(ct, "Login failed", Toast.LENGTH_SHORT).show();
                ct.startActivity(new Intent(ct,Login.class));
            }

            return 0;
        }

        return 0;
    }

    public void display() {

        readable = getReadableDatabase();
        Cursor c = readable.query("userdata", new String[]{"name", "email", "mobileno", "password", "address"}, null, null, null, null, null);
        while (c.moveToNext()) {
            String name = c.getString(0);
            String email = c.getString(1);
            String mobileno = c.getString(2);
            String password = c.getString(3);
            String address = c.getString(4);

            Toast.makeText(ct, "" + name + "" + email + "" + mobileno + "" + password + "" + address, Toast.LENGTH_SHORT).show();

        }
    }

    public long edit(String d, String s, String a, String c, String userna) {

        ContentValues values = new ContentValues();
        values.put("name", d);
        values.put("email", s);
        values.put("mobileno", a);
        values.put("address", c);


        writable = getWritableDatabase();
        long e =writable.update("userdata", values, "email=?", new String[]{userna});
        if (e > 0) {
            Toast.makeText(ct, "Details updated successfully", Toast.LENGTH_SHORT).show();
            ct.startActivity(new Intent(ct,Profile.class));
        } else {
            Toast.makeText(ct, "failed to update details", Toast.LENGTH_SHORT).show();

        }
        return 0;
    }

    public long cart(String s, byte[] s1, String s2, String s3, String userna) {
        writable = getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put("foodname", s);
            values.put("foodimage", s1);
            values.put("rating", s2);
            values.put("price", s3);
            values.put("q","1");
            values.put("t",s3);
            values.put("usermail",userna);
            long d=writable.insert("cart", null, values);
           return d;
        }


    public ArrayList getcart(String userna) {
        readable = getReadableDatabase();
        Cursor c = readable.rawQuery("select * from cart where usermail='"+userna+"';",null);
        ArrayList fn = new ArrayList();

        while (c.moveToNext()) {
            String foodname = c.getString(0);
            byte[] foodimage = c.getBlob(1);
            String rating=c.getString(2);
            String price=c.getString(3);
            String q=c.getString(4);
            String t=c.getString(5);
            String u=c.getString(6);
            fn.add(new Cartconstructor(foodname,foodimage,rating,price,q,t));
        }
        return fn;

    }


    public ArrayList getuserdetails(String username) {
        readable = getReadableDatabase();
        Cursor c = readable.rawQuery("select name,email,mobileno,address from userdata where email='"+username+"';", null);
        ArrayList u = new ArrayList();
        while (c.moveToNext()) {
            String name = c.getString(0);
            String email = c.getString(1);
            String mobileno = c.getString(2);
            String address = c.getString(3);
            u.add(name);
            u.add(email);
            u.add(mobileno);
            u.add(address);
           }

        return u;
    }


    public void itemdataenter(String n, String image, String r, String p, byte[] c) {

        writable = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("itemname", n);
        values.put("itemrating", image);
        values.put("itemprice", r);
        values.put("itemcategory", p);
        values.put("itemimage", c);

        long a = writable.insert("fooditems", null, values);
        if (a > 0) {
            Toast.makeText(ct, "item added into database", Toast.LENGTH_SHORT).show();

        } else {
            Toast.makeText(ct, "failed to add item", Toast.LENGTH_SHORT).show();
        }
    }


    public ArrayList<String> itemdataretrieve() {

        readable = getReadableDatabase();
        Cursor c = readable.rawQuery("select * from fooditems", null);
        ArrayList item = new ArrayList();

        while (c.moveToNext()) {
            String fn = c.getString(0);
            String fr = c.getString(1);
            String fp = c.getString(2);
            String fc = c.getString(3);
            byte[] fi = c.getBlob(4);
            item.add(new FoodExplore(fn, fr, fp, fc, fi));

        }
        return item;
    }

    public ArrayList<String> itemdataretrieveuser() {

        readable = getReadableDatabase();
        Cursor c =readable.rawQuery("select * from fooditems",null);

        ArrayList user = new ArrayList();

        while (c.moveToNext()) {
            String fn = c.getString(0);
            String fr = c.getString(1);
            String fp = c.getString(2);
            String fc=c.getString(3);
            byte[] fi = c.getBlob(4);
            user.add(new ExploreUser(fn,fr,fp,fc,fi));
        }
        return user;
    }

    public long itemdataupdate(String s, String n, String r, String p, String c, byte[] byteArray) {
        writable = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("itemname", n);
        values.put("itemrating",r);
        values.put("itemprice", p);
        values.put("itemcategory", c);
        values.put("itemimage", byteArray);
        long up=writable.update("fooditems", values, "itemname=?", new String[]{s});
        return up;
    }

    public ArrayList itemdataretrieve1() {

        readable = getReadableDatabase();
        Cursor c = readable.rawQuery("select * from fooditems", null);
        ArrayList item = new ArrayList();


        while (c.moveToNext()) {
            String fn = c.getString(0);
            String fr = c.getString(1);
            String fp = c.getString(2);
            String fc = c.getString(3);
            byte[] fi = c.getBlob(4);
            item.add(new ExploreUser(fn, fr, fp, fc, fi));

        }
        return item;
    }

    public long deleteitem(String name) {
        writable=getWritableDatabase();
        long del=writable.delete("fooditems","itemname=?",new String[]{name});
        return del;
    }


    public long delcart(String del) {
        writable=getWritableDatabase();
        long d=writable.delete("cart","foodname=?",new String[]{del});
        return d;
    }

    public long placeorder(String userna, ArrayList fn, String s) {

        writable = getWritableDatabase();
        ContentValues values = new ContentValues();
        String fname= String.valueOf(fn);
        values.put("username", userna);
        values.put("foodname", fname);
        values.put("amount", s);
        values.put("status", "order to be confirmed");

        long a = writable.insert("orders", null, values);

        return a;
    }
    public ArrayList<String> orderretrieve(String userna) {

        readable = getReadableDatabase();
        Cursor c = readable.rawQuery("select * from orders where username='"+userna+"';", null);
        ArrayList u = new ArrayList();
        while (c.moveToNext()) {
            String id=c.getString(0);
            String username = c.getString(1);
            String foodname = c.getString(2);
            String amount = c.getString(3);
            String status = c.getString(4);
            u.add(new Orderconstructor(id,username,foodname,amount,status));


        }

        return u;

    }
    public ArrayList<String> orderretrieve1() {

        readable = getReadableDatabase();
        Cursor c = readable.rawQuery("select * from orders", null);
        ArrayList u = new ArrayList();
        while (c.moveToNext()) {
            String id=c.getString(0);
            String username = c.getString(1);
            String foodname = c.getString(2);
            String amount = c.getString(3);
            String status = c.getString(4);
            u.add(new AdminOrderConstructor(id,username,foodname,amount,status));
        }

        return u;

    }

    public void ordersuccess(String userna) {
        writable=getWritableDatabase();
        writable.delete("cart","usermail=?",new String[]{userna});
    }


    public Long oderstatus(String id) {
        writable = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("status","order confirmed");
        long up=writable.update("orders", values, "id=?", new String[]{id});
        return up;

    }
}