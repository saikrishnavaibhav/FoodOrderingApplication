package com.example.srkr.foodieapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.afollestad.materialdialogs.MaterialDialog;

import java.util.ArrayList;

/**
 * Created by HP on 4/17/2018.
 */

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.Viewholder>  {

    ArrayList food;
    Context ct;
    Mydatabase mydatabase;
    ProgressDialog pd;
    String username,foodname,amount,status;

    public OrderAdapter(Orders adminexplore, ArrayList<String> food) {
        this.ct=adminexplore;
        this.food=food;
    }

    @Override
    public OrderAdapter.Viewholder onCreateViewHolder(ViewGroup parent, int viewType) {
        mydatabase=new Mydatabase(ct);
        pd=new ProgressDialog(ct);
        pd.setTitle("Deleting Item...");
        pd.setMessage("processing please wait...!!");
        pd.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        pd.setMax(8);
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.orderuser,parent,false);
        return new OrderAdapter.Viewholder(v);

    }

    @Override
    public void onBindViewHolder(OrderAdapter.Viewholder holder, int position) {
        final Orderconstructor fooditem= (Orderconstructor) food.get(position);

        holder.f.setText(fooditem.getFoodname());
        holder.a.setText(fooditem.getAmount());
        holder.s.setText(fooditem.getStatus());

    }

    @Override
    public int getItemCount() {
        return food.size();
    }

    public class Viewholder extends RecyclerView.ViewHolder {

        TextView u,f,a,s;
        LinearLayout linearLayout;
        public Viewholder(View itemView) {
            super(itemView);

            f=(TextView)itemView.findViewById(R.id.foodname);
            a=(TextView)itemView.findViewById(R.id.amount);
            s=(TextView)itemView.findViewById(R.id.status);
            linearLayout=(LinearLayout)itemView.findViewById(R.id.linearLayout);
        }
    }
}

