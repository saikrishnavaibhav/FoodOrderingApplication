package com.example.srkr.foodieapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;

public class Orders extends AppCompatActivity {

    RecyclerView recyclerView;

    Mydatabase mydatabase;
    SharedPreferences sharedPreferences;
    String userna;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orders);

       ArrayList food = new ArrayList();
        mydatabase = new Mydatabase(this);


        sharedPreferences=getSharedPreferences("Login", Context.MODE_PRIVATE);
        userna=sharedPreferences.getString("username","");

        food = mydatabase.orderretrieve(userna);


        recyclerView = (RecyclerView) findViewById(R.id.recycleorders);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new OrderAdapter(this, food));
    }
}
