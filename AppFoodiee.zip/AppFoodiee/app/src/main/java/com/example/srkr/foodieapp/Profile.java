package com.example.srkr.foodieapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Profile extends AppCompatActivity {

    TextView user,mobilno,address,email;
    Mydatabase mydatabase;
    ArrayList foodname,foodimage,rating,price;
    SharedPreferences sharedPref;
    SharedPreferences.Editor editor;
    String uu,ue,um,ua;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        user=(TextView)findViewById(R.id.username);
        email=(TextView)findViewById(R.id.email);
        mobilno=(TextView)findViewById(R.id.mobileno);
        address=(TextView)findViewById(R.id.address);


        mydatabase = new Mydatabase(this);

        SharedPreferences preferences =getSharedPreferences("Login", Context.MODE_PRIVATE);


        // Toast.makeText(this, ""+user, Toast.LENGTH_SHORT).show();
            String userna=preferences.getString("username","");

            if(userna.equals("admin")){
                user.setText("admin");
                email.setText("admin");
                mobilno.setText("admin");
                address.setText("admin");
            }
            else {
                ArrayList u = mydatabase.getuserdetails(userna);
                uu = u.get(0).toString();
                ue = u.get(1).toString();
                um = u.get(2).toString();
                ua = u.get(3).toString();
                user.setText(uu);
                email.setText(ue);
                mobilno.setText(um);
                address.setText(ua);
            }

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);



    }
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.home:
                    Intent h=new Intent(Profile.this,MainHome.class);
                    startActivity(h);
                    return true;
                case R.id.explore:
                    Intent e=new Intent(Profile.this,UserExplore.class);
                    startActivity(e);
                    return true;

                case R.id.account:
                    Intent a=new Intent(Profile.this,Profile.class);
                    startActivity(a);
                    return true;
            }
            return false;
        }
    };


    public void edit(View view) {

        SharedPreferences preferences =getSharedPreferences("Login", Context.MODE_PRIVATE);


        // Toast.makeText(this, ""+user, Toast.LENGTH_SHORT).show();
        String userna=preferences.getString("username","");

        if(userna.equals("admin")) {
            Toast.makeText(this, "Admin info cannot be modified", Toast.LENGTH_SHORT).show();
        }else {
            Intent e = new Intent(Profile.this, Edituser.class);
            e.putExtra("u", uu);
            e.putExtra("e", ue);
            e.putExtra("m", um);
            e.putExtra("a", ua);

            startActivity(e);
        }
    }

    public void orders(View view) {
        SharedPreferences preferences =getSharedPreferences("Login", Context.MODE_PRIVATE);


        // Toast.makeText(this, ""+user, Toast.LENGTH_SHORT).show();
        String userna=preferences.getString("username","");

        if(userna.equals("admin")) {
            Intent i=new Intent(Profile.this,OrderAdmin.class);
            startActivity(i);
        }
        else{
            Intent i=new Intent(Profile.this,Orders.class);
            startActivity(i);
        }

    }

    public void logout(View view) {

        SharedPreferences preferences =getSharedPreferences("Login", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.clear();
        editor.commit();
        finish();
        Intent logout=new Intent(Profile.this,Login.class);
        startActivity(logout);
        finish();
    }
}
