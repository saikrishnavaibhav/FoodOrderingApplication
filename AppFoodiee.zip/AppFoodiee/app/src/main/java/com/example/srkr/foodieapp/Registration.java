package com.example.srkr.foodieapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.utility.RegexTemplate;
import com.google.common.collect.Range;

import static com.basgeekball.awesomevalidation.ValidationStyle.BASIC;
import static com.basgeekball.awesomevalidation.ValidationStyle.UNDERLABEL;

public class Registration extends AppCompatActivity {

    EditText name,email,mobileno,pswd,cnfpwd,address;
    Button register;
    Mydatabase mydatabase;
    ProgressDialog pd;
    AwesomeValidation awesomeValidation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        name=(EditText)findViewById(R.id.name);
        email=(EditText)findViewById(R.id.email);
        mobileno=(EditText)findViewById(R.id.mobileno);
        pswd=(EditText)findViewById(R.id.password);
        cnfpwd=(EditText)findViewById(R.id.confirmpassword);
        address=(EditText)findViewById(R.id.address);

        register=(Button)findViewById(R.id.Register);
        pd=new ProgressDialog(this);
        pd.setTitle("Registering...");
        pd.setMessage("processing please wait...!!");
        pd.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        pd.setMax(8);
        mydatabase=new Mydatabase(this);

        awesomeValidation = new AwesomeValidation(BASIC);

        awesomeValidation.addValidation(this, R.id.name, RegexTemplate.NOT_EMPTY,R.string.name);
        awesomeValidation.addValidation(this, R.id.email, Patterns.EMAIL_ADDRESS, R.string.email);
        String regexPassword = ".{7,}";
        awesomeValidation.addValidation(this, R.id.password, regexPassword, R.string.password);
        awesomeValidation.addValidation(this, R.id.confirmpassword, R.id.password, R.string.cnfpassword);

        awesomeValidation.addValidation(this, R.id.mobileno, "^[0-9]{10}$", R.string.mobileno);
        awesomeValidation.addValidation(this, R.id.address, RegexTemplate.NOT_EMPTY,R.string.address);

    }

    public void register(View view) {


        pd.show();
        pd.setCancelable(false);

        String n=name.getText().toString();
        String e=email.getText().toString();
        String m=mobileno.getText().toString();
        String p=pswd.getText().toString();
        String cp=cnfpwd.getText().toString();
        String a=address.getText().toString();
        pd.dismiss();
        if (awesomeValidation.validate()){
            pd.show();
            pd.setCancelable(false);

            long success=   mydatabase.insertdata(n,e,m,p,a);
                if(success>0){

                    Toast.makeText(this, "registration successful", Toast.LENGTH_SHORT).show();

                    Intent reg=new Intent(Registration.this,MainHome.class);
                    reg.putExtra("u",e);
                    reg.putExtra("p",p);
                    startActivity(reg);
                    finish();

                }
                else {
                    pd.dismiss();
                    Toast.makeText(this, "reg unsuccessful", Toast.LENGTH_SHORT).show();
                }


            }

        }
    public void display(View view) {
        mydatabase.display();
    }
}
