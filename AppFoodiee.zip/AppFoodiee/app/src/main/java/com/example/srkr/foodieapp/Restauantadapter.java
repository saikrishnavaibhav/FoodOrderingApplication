package com.example.srkr.foodieapp;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

/**
 * Created by HP on 3/10/2018.
 */

public class Restauantadapter extends RecyclerView.Adapter<Restauantadapter.Viewholder> {

    ArrayList<String> restaurantname,restaurantimage;
    Context ct;

    public Restauantadapter(Restaurants restaurants, ArrayList<String> restaurantname, ArrayList<String> restaurantimage) {
        this.restaurantname=restaurantname;
        this.restaurantimage=restaurantimage;
        this.ct=restaurants;
    }

    @Override
    public Viewholder onCreateViewHolder(ViewGroup parent, int viewType) {

        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.restaurantlist,parent,false);
        return new Viewholder(v);

    }

    @Override
    public void onBindViewHolder(Viewholder holder, int position) {

        holder.t1.setText(restaurantname.get(position).toString());
        String img=restaurantimage.get(position).toString();
        try {
            InputStream inputstream=ct.getAssets().open(img);
            Drawable d=Drawable.createFromStream(inputstream,null);
            holder.i1.setImageDrawable(d);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    @Override
    public int getItemCount() {
        return restaurantname.size();
    }

    public class Viewholder extends RecyclerView.ViewHolder {
        TextView t1;
        ImageView i1;
        public Viewholder(View itemView) {
            super(itemView);
            t1=(TextView)itemView.findViewById(R.id.restauantname);
            i1=(ImageView)itemView.findViewById(R.id.restauantimage);


        }
    }
}
