package com.example.srkr.foodieapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;

public class Restaurants extends AppCompatActivity {
    RecyclerView recyclerView;
    ArrayList<String> restaurantname,restaurantimage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurants);
        restaurantname=new ArrayList<>();
        restaurantimage=new ArrayList<>();



        final InputStream inputStream=getResources().openRawResource(R.raw.restaurantdata);
        StringBuilder builder=new StringBuilder();
        final BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(inputStream));
        String line;
        try {
            while ((line=bufferedReader.readLine())!=null){

                builder.append(line);
            }
            String myjsondata=builder.toString();
            JSONObject data=new JSONObject(myjsondata);
            JSONArray jsondata=data.getJSONArray("jsondata");
            String name,image;
            for (int i=0;i<=jsondata.length();i++)
            {

                JSONObject a=jsondata.getJSONObject(i);
                name=a.getString("restaurantname");
                image=a.getString("restaurantimage");
                restaurantname.add(name);
                restaurantimage.add(image);

            }


        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }

        recyclerView=(RecyclerView)findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new Restauantadapter(this,restaurantname,restaurantimage));
    }
}
