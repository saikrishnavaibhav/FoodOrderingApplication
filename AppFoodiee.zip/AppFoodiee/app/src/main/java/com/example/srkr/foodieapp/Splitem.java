package com.example.srkr.foodieapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Splitem extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    View customToast;
    RecyclerView recyclerView;
    ArrayList<String> foodname,foodimage,rating,price;
    Mydatabase mydatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splitem);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        customToast=getLayoutInflater().inflate(R.layout.customtoast,(ViewGroup)findViewById(R.id.customtoast));
        Toast t=Toast.makeText(this,"vaibhav",Toast.LENGTH_SHORT);
        t.setGravity(Gravity.CENTER,0,0);
        t.setView(customToast);
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.open, R.string.close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        foodname=new ArrayList<>();
        foodimage=new ArrayList<>();
        rating=new ArrayList<>();
        price=new ArrayList<>();

        SharedPreferences sharedPreferences=getSharedPreferences("Login", Context.MODE_PRIVATE);
        String userna=sharedPreferences.getString("username","");


        final InputStream inputStream=getResources().openRawResource(R.raw.fooddata);
        StringBuilder builder=new StringBuilder();
        final BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(inputStream));
        String line;
        try {
            while ((line=bufferedReader.readLine())!=null){

                builder.append(line);
            }
            String myjsondata=builder.toString();
            JSONObject data=new JSONObject(myjsondata);
            JSONArray jsondata=data.getJSONArray("biryanidata");
            String name,image,rtng,pricee;
            for (int i=0;i<=jsondata.length();i++)
            {

                JSONObject a=jsondata.getJSONObject(i);
                name=a.getString("name");
                image=a.getString("image");
                rtng=a.getString("rating");
                pricee=a.getString("price");
                foodname.add(name);
                foodimage.add(image);
                rating.add(rtng);
                price.add(pricee);

            }


        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }

        recyclerView=(RecyclerView)findViewById(R.id.foodrecycle);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new Splitemsadapter(this,foodname,foodimage,rating,price,userna,t));

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

  /*  @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement

        return super.onOptionsItemSelected(item);
    }
*/
    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        if (id == R.id.special_items) {
            Intent salad=new Intent(Splitem.this,Splitem.class);
            startActivity(salad);
            // Handle the camera action
        } else if (id == R.id.salads) {
            Intent salad=new Intent(Splitem.this,salads.class);
            startActivity(salad);

        } else if (id == R.id.juices) {
            Intent juices=new Intent(Splitem.this,juices.class);
            startActivity(juices);

        } else if (id == R.id.starters) {
            Intent salad=new Intent(Splitem.this,salads.class);
            startActivity(salad);

        } else if (id == R.id.icecreams) {
            Intent salad = new Intent(Splitem.this, Icecreams.class);
            startActivity(salad);
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void click(View view) {
        Intent cart=new Intent(Splitem.this,Cart.class);
        startActivity(cart);
    }

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.home:
                    Intent h=new Intent(Splitem.this,MainHome.class);
                    startActivity(h);
                    return true;
                case R.id.explore:
                    Intent e=new Intent(Splitem.this,MainHome.class);
                    startActivity(e);
                    return true;
                case R.id.account:
                    Intent a=new Intent(Splitem.this,Profile.class);
                    startActivity(a);
                    return true;
            }
            return false;
        }
    };


}
