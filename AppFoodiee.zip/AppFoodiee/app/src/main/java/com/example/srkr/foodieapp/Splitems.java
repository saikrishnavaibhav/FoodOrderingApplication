package com.example.srkr.foodieapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

/**
 * Created by HP on 3/16/2018.
 */

public class Splitems extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    RecyclerView recyclerView;
    ArrayList<String> foodname,foodimage,rating,price;

    private DrawerLayout mdrawer;
    NavigationView navigationView;
    private ActionBarDrawerToggle mtoggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splitems);
        foodname=new ArrayList<>();
        foodimage=new ArrayList<>();
        rating=new ArrayList<>();
        price=new ArrayList<>();

        mdrawer=(DrawerLayout)findViewById(R.id.drawer);

        mtoggle=new ActionBarDrawerToggle(this,mdrawer,R.string.open,R.string.close);
        mdrawer.addDrawerListener(mtoggle);
        mtoggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

       // navigationView=(NavigationView)findViewById(R.id.navigationview);
       // navigationView.setNavigationItemSelectedListener(this);




        final InputStream inputStream=getResources().openRawResource(R.raw.splitemdata);
        StringBuilder builder=new StringBuilder();
        final BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(inputStream));
        String line;
        try {
            while ((line=bufferedReader.readLine())!=null){

                builder.append(line);
            }
            String myjsondata=builder.toString();
            JSONObject data=new JSONObject(myjsondata);
            JSONArray jsondata=data.getJSONArray("splitemdata");
            String name,image,rtng,pricee;
            for (int i=0;i<=jsondata.length();i++)
            {

                JSONObject a=jsondata.getJSONObject(i);
                name=a.getString("foodname");
                image=a.getString("foodimage");
                rtng=a.getString("rating");
                pricee=a.getString("price");
                foodname.add(name);
                foodimage.add(image);
                rating.add(rtng);
                price.add(pricee);

            }


        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        recyclerView=(RecyclerView)findViewById(R.id.foodrecycle);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        //recyclerView.setAdapter(new Splitemsadapter(this,foodname,foodimage,rating,price));
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(mtoggle.onOptionsItemSelected(item))
        {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id=item.getItemId();
        switch (id) {
            case (R.id.special_items):
                Intent Splitems = new Intent(Splitems.this, Home.class);
                startActivity(Splitems);
                break;
        }
        return true;
    }
}
