package com.example.srkr.foodieapp;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.cepheuen.elegantnumberbutton.view.ElegantNumberButton;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

/**
 * Created by HP on 3/18/2018.
 */

public class Startersadapter extends RecyclerView.Adapter<Startersadapter.Viewholder> {

    ArrayList<String> foodname,foodimage,rating,price;
    Context ct;
    Mydatabase mydatabase;
    String userna;
    int no;
    Toast t;

    public Startersadapter(Starters splitems, ArrayList<String> foodname, ArrayList<String> foodimage, ArrayList<String> rating, ArrayList<String> price, String userna, Toast t) {
        this.foodname=foodname;
        this.foodimage=foodimage;
        this.rating=rating;
        this.price=price;
        this.ct=splitems;
        this.userna=userna;
        this.t=t;
    }

    @Override
    public Viewholder onCreateViewHolder(ViewGroup parent, int viewType) {
        mydatabase=new Mydatabase(ct);
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.fooditems,parent,false);
        return new Startersadapter.Viewholder(v);

    }


    @Override
    public void onBindViewHolder(final Startersadapter.Viewholder holder, final int position) {

        holder.fn.setText(foodname.get(position).toString());
        holder.rt.setText(rating.get(position).toString());
        holder.pr.setText(price.get(position).toString());
        String img=foodimage.get(position).toString();

        holder.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Bitmap bitmap = ((BitmapDrawable)holder.fi.getDrawable()).getBitmap();
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
                byte[] byteArray = stream.toByteArray();
                long d= mydatabase.cart(foodname.get(position),byteArray,rating.get(position), price.get(position), userna);
                if(d>0){
                    t.show();
                }
                else{
                    Toast.makeText(ct, "item is available in cart", Toast.LENGTH_SHORT).show();

                }
            }
        });

        try {
            InputStream inputstream=ct.getAssets().open(img);
            Drawable d=Drawable.createFromStream(inputstream,null);
            holder.fi.setImageDrawable(d);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    @Override
    public int getItemCount() {
        return foodname.size();
    }

    public class Viewholder extends RecyclerView.ViewHolder {
        TextView fn,rt,pr;
        ImageView fi;
        Button button;
        public Viewholder(View itemView) {
            super(itemView);
            fn=(TextView)itemView.findViewById(R.id.foodname);
            rt=(TextView)itemView.findViewById(R.id.rating);
            pr=(TextView)itemView.findViewById(R.id.price);
            fi=(ImageView)itemView.findViewById(R.id.foodimage);
            button=(Button)itemView.findViewById(R.id.addtocart);

        }
    }
}
