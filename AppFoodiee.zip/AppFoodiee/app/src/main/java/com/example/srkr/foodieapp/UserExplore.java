package com.example.srkr.foodieapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;

public class UserExplore extends AppCompatActivity {
    RecyclerView recyclerView;
    Mydatabase mydatabase;
    ArrayList food;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_explore);

   //     Toast.makeText(this, "hii", Toast.LENGTH_SHORT).show();
        food = new ArrayList<>();
        mydatabase = new Mydatabase(this);
        food = mydatabase.itemdataretrieve1();


        SharedPreferences sharedPreferences=getSharedPreferences("Login", Context.MODE_PRIVATE);
        String userna=sharedPreferences.getString("username","");


        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new UserExplreAdapter(this, food,userna));

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);



    }
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.home:
                    Intent h=new Intent(UserExplore.this,MainHome.class);
                    startActivity(h);
                    return true;
                case R.id.explore:
                    Intent e=new Intent(UserExplore.this,UserExplore.class);
                    startActivity(e);
                    return true;

                case R.id.account:
                    Intent a=new Intent(UserExplore.this,Profile.class);
                    startActivity(a);
                    return true;
            }
            return false;
        }
    };


    public void click(View view) {
        Intent cart=new Intent(UserExplore.this,Cart.class);
        startActivity(cart);
    }
}
