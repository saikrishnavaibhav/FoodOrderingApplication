package com.example.srkr.foodieapp;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.cepheuen.elegantnumberbutton.view.ElegantNumberButton;

import java.util.ArrayList;

/**
 * Created by HP on 3/31/2018.
 */

public class UserExplreAdapter extends RecyclerView.Adapter<UserExplreAdapter.Viewholder>  {
    ArrayList food;
    Context ct;
    Mydatabase mydatabase;
    String userna;
    int no;

    public UserExplreAdapter(UserExplore userExplore, ArrayList<String> food, String userna) {
        this.food=food;
        this.ct=userExplore;
        this.userna=userna;

    }

    @Override
    public UserExplreAdapter.Viewholder onCreateViewHolder(ViewGroup parent, int viewType) {
        mydatabase=new Mydatabase(ct);
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.userexploreitemslist,parent,false);
        return new UserExplreAdapter.Viewholder(v);

    }

    @Override
    public void onBindViewHolder(UserExplreAdapter.Viewholder holder, int position) {
        final ExploreUser fooditem= (ExploreUser) food.get(position);

        holder.fn.setText(fooditem.getName());
        holder.rt.setText(fooditem.getRating());
        holder.pr.setText(fooditem.getPrice());
        holder.ct.setText(fooditem.getCategory());
        final byte[] foodImage = fooditem.getImage();
        Bitmap bitmap = BitmapFactory.decodeByteArray(foodImage, 0, foodImage.length);
        holder.fi.setImageBitmap(bitmap);


        holder.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                 mydatabase.cart(fooditem.getName(),fooditem.getImage(),fooditem.getRating(), fooditem.getPrice(), userna);
            }
        });

    }

    @Override
    public int getItemCount() {
        return food.size();
    }

    public class Viewholder extends RecyclerView.ViewHolder {
        TextView fn,rt,pr,ct;
        ImageView fi;
        Button button;


        public Viewholder(View itemView) {
            super(itemView);
            fn=(TextView)itemView.findViewById(R.id.foodname);
            rt=(TextView)itemView.findViewById(R.id.rating);
            pr=(TextView)itemView.findViewById(R.id.price);
            ct=(TextView)itemView.findViewById(R.id.category);
            fi=(ImageView)itemView.findViewById(R.id.foodimage);
            button=(Button)itemView.findViewById(R.id.addtocart);

        }
    }
}
